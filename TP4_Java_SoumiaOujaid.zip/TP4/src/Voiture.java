import java.io.Serializable;
public class Voiture extends Vehicule  implements Decapotable{

	 
	 private static int MaxVoitures = 10;
	 private static int nbVoitures = 0;
	 private static int capacite = 100;
	 
	 private Carburant carburant;
	 private int Periodicite;
	 private boolean TReplie; 
	 
	 //Constructeur
	 private Voiture (int annee_Model, Carburant carburant) {
		 super(annee_Model);
		 this.setMatricule(this.getClass().getName()+":"+ ++nbVoitures);
		 this.carburant = carburant;
	 }
	 
	 //Creer Voiture
	 public static Voiture CreerVoiture(int annee_Model, Carburant carburant) {
		 if (nbVoitures < MaxVoitures) 
			 return new Voiture(annee_Model,carburant);
		 else 
			 System.out.println("le parc porte un nombre Max des voitures");
		 return null;
	 } 
	 
	 //add Carburant
	 public void addCarburant(double carburant) {
		 
		 if (getCarburant()+carburant <= capacite)
			 setCarburant(getCarburant()+carburant);
		 else {
			 double max_carburant = capacite - getCarburant();
			 this.setCarburant(capacite); // donc: (max_carburant - capacité ) donc cette quantité a perdu. 
		 }
	 } 
	
	 // implémentation de la méthode abstract typeCarburant existe dans Motorisation
	 public Carburant typeCarburant() {
			 return carburant;	 
	 }
	 
	 // implémentation de la méthode abstract periodiciteVidange existe dans Motorisation
	 public void periodiciteVidange(){
		 switch (carburant) {
			 case Diesel : Periodicite = 10;
			 break;
			 case Essence: Periodicite = 12; 
			 break;
			 case Gaz: Periodicite = 18; 
			 break;
			 default: Periodicite = 10; 
			 break;
		 }
	 }

	//implémentation de la méthode abstract periodiciteVidange existe dans Decapotable
	public void replieLeToit() {
		 TReplie = true;
	} 
	
	// to String
	@Override
	public String toString() {
		 return "Voiture (" + super.toString() +"), type du carburant: "+ carburant +", periodicite de vidange:"+ Periodicite +" mois";
	}

	
	

	
}
