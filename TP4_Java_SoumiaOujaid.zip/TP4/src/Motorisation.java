
public interface Motorisation {
	
	public Carburant typeCarburant();
    public void periodiciteVidange();

}
