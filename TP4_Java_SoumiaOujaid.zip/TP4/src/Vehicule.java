import java.io.Serializable; 
public abstract class Vehicule implements Motorisation,Serializable{
	
	
	private static int NbVoitures = 0;
    private static int NbCamions = 0;
    private static int NbAutocars = 0;
	
	private String Matricule;
	private int annee_Model;
	private double prix;
	private double Carburant; 
	
	//Constructeur
	public Vehicule(int annee){
		this.annee_Model = annee; 
	} 

	//getters && setters: Matricule
	public String getMatricule() {
		return this.Matricule;
	}
	public void setMatricule( String matricule) {
		this.Matricule = matricule;
	}
	
	//getters && setters:Model
	public int getAnneeMode() {
		return this.annee_Model;
	}
	public void setAnneeMode(int anneeModel) {
		this.annee_Model =anneeModel;
	}
	
	
	//getters && setters:prix
	public double getPrix() {
		return prix;
	}
	public void setPrix(double pr) {
		this.prix =pr;
	}
	
	//getters && setters: Carburant
	public double getCarburant() {
		return this.Carburant;
	}
	public void setCarburant(double carburant) {
		this.Carburant =carburant;
	}
	
	//to String
	@Override
	 public String toString() {
        return "Matricule -> " + Matricule + " ,Année du modèle-> " + annee_Model + ", Prix-> " + prix;
    } 
}
