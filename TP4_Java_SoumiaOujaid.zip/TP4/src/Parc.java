import java.io.*; 

public class Parc {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		 
		
		//creation des voitures
		
		Voiture voiture1 = Voiture.CreerVoiture(2013,Carburant.Diesel);
		voiture1.setPrix(100000);
		Voiture voiture2 = Voiture.CreerVoiture(2014,Carburant.Essence);
		voiture2.setPrix(200000);
		
		//creation des camions
		Camion camion1 = Camion.CreerCamion(2013,Carburant.Diesel);
		camion1.setPrix(100000000);
		Camion camion2 = Camion.CreerCamion(2010,Carburant.Gaz);
		camion2.setPrix(200000000);
		
		// add Carburant pour les voitures
		voiture1.addCarburant(30); 
		voiture1.periodiciteVidange();
		System.out.println(voiture1.toString());
		
		voiture2.addCarburant(40); 
		voiture2.periodiciteVidange();
		System.out.println(voiture2.toString());
		
		//add Carburant pour les camions
		camion1.addCarburant(10); 
		camion1.periodiciteVidange();
		System.out.println(camion1.toString());
		
		camion2.addCarburant(5); 
		camion2.periodiciteVidange();
		System.out.println(camion2.toString());
		
		
		//Sérialisation
		FileOutputStream tp4 = new FileOutputStream("TP4");
		ObjectOutputStream objet = new ObjectOutputStream(tp4);
		objet.writeObject(voiture1);
		objet.writeObject(voiture2);
		objet.close(); 
		tp4.close();
		
		//Désérialisation
		FileInputStream fil = new FileInputStream ("TP4");
		ObjectInputStream objet1 = new ObjectInputStream(fil);
		Voiture voiture3 = (Voiture)objet1.readObject();
		Voiture voiture4 = (Voiture)objet1.readObject();
		objet1.close(); 
		fil.close();
		System.out.println("\n\n\n" + voiture1.toString());

	}

}
