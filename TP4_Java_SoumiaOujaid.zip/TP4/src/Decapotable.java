
public interface Decapotable {
	
	public void replieLeToit();

}
