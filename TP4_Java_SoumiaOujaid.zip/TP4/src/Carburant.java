
public enum Carburant {
	
	  	Diesel,
	    Essence,
	    Gaz
	

}
