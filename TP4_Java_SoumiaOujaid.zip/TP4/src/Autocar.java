import java.io.Serializable;
public class Autocar extends Vehicule {
	
	 private static int MaxAutocars = 10;
	 private static int nbAutocars = 0;
	 private static int capacite = 100;
	 
	 private Carburant carburant;
	 private int Periodicite;
	 private boolean TReplie;
	 
	 
	public Autocar(int annee , Carburant carburant) {
			super(annee);
		 this.setMatricule(this.getClass().getName()+":"+ ++ nbAutocars);
		 this.carburant = carburant;
	}
	
	//Creer Voiture
	public static Autocar CreerAutocar(int annee_Model, Carburant carburant) {
		 if (nbAutocars < MaxAutocars) 
			 return new Autocar(annee_Model,carburant);
		 else 
			 System.out.println("le parc porte un nombre Max des Camions");
		 return null;
	} 
	
	 //add Carburant
	 public void addCarburant(double carburant) {
		 double C= getCarburant()+carburant;
		 if (C <= capacite)
			 setCarburant(C);
		 else {
			 double max_carburant = capacite - getCarburant();
			 this.setCarburant(capacite); // donc: (max_carburant - capacité ) donc cette quantité a perdu. 
		 }
	 } 
	 
	// implémentation de la méthode abstract typeCarburant existe dans Motorisation
	public Carburant typeCarburant() {
		return carburant;
	}

	// implémentation de la méthode abstract periodiciteVidange existe dans Motorisation
	public void periodiciteVidange() {
		switch (carburant) {
		 case Diesel : Periodicite = 10;
		 break;
		 case Essence: Periodicite = 12; 
		 break;
		 case Gaz: Periodicite = 18; 
		 break;
		 default: Periodicite = 10; 
		 break;
	 }
	}

	//implémentation de la méthode abstract periodiciteVidange existe dans Decapotable
	public void replieLeToit() {
		TReplie = true;
	}
	
	// to String
	@Override
	public String toString() {
		 return "Camion (" + super.toString() +"), type du carburant: "+ carburant +", periodicite de vidange:"+ Periodicite +" mois";
	} 
		
}
